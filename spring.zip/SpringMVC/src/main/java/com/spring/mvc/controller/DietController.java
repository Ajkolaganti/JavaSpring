package com.spring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DietController {
	@Autowired
	FoodService foodService;
	
	@RequestMapping(value = "/getFood", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Food getFood() {
		Food f = foodService.getFood();
		return f;
	}

	@RequestMapping(value = "/getFood", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Food save(Food f)
	{
	 f.setName("alpha");
	return f;
	}

}
