package com.spring.mvc.controller;

import org.springframework.stereotype.Service;

@Service
public class FoodServiceImpl implements FoodService {

	
	public Food getFood() {
		
		Food f= new Food("Vegetarian", "salad");
		return f;
		
	}


	

}
