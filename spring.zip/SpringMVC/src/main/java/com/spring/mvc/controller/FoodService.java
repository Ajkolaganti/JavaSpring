package com.spring.mvc.controller;

public interface FoodService {

	
	public Food getFood();
	
}
